function start() {
    header();
    topnav();
    main();
    footer();
  }
  
  function header() {
    const header = document.createElement('div');
    header.className = 'header';
    header.innerHTML = `
      <h1>Jared Ong's Website</h1>
    `;
    document.body.appendChild(header);
  }
  
  function topnav() {
    const topnav = document.createElement('div');
    topnav.className = 'topnav';
    topnav.innerHTML = `
      <a href="#" onclick="showContent('default')">Topic 1</a>
      <a href="#" onclick="showContent('item2')">Topic 2</a>
      <a href="#" onclick="showContent('item3')">Topic 3</a>
      <li class="dropdown">
        <a href="javascript:void(0)" class="dropbtn">Extra</a>
        <div class="dropdown-content">
          <a href="#" onclick="cal()">Calculator</a>
          <a href="#" onclick="sort()">Text Sorter</a>
        </div>
      </li>
    `;
    document.body.appendChild(topnav);
  }
  
  function main() {
    const main = document.createElement('div');
    main.className = 'row';
    main.innerHTML = `
      <div class="leftcolumn" id="mainContent">
        <div class="card" id="defaultContent">
          <h2>Sample Gundam Website HTML</h2>
          <h5>Made on June 6, 2024</h5>
          <div class="fakeimg" style="overflow: hidden;">
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture2.png" alt="Image" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <h2>Gundam</h2>
          <p>Gundam is a Japanese military science fiction media franchise. Created by Yoshiyuki Tomino and Sunrise, the franchise features giant robots, or mecha, with the name "Gundam".</p>
        </div>
      </div>
      <div class="rightcolumn">
        <div class="card">
          <h2>About Me</h2>
          <div style="height:100px; overflow: hidden;">
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture.jpg" alt="Image" style="width: 100%; height: 100%; object-fit: contain;">
          </div>
          <p>My name is Jared Ong studying LBYCPG3 -EQ1</p>
        </div>
        <div class="card">
          <h3>Popular Post</h3>
          <div class="fakeimg"><p>Gundam Image 1</p>
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture3.png" alt="Image" style="width: 80%; height: 50%; object-fit: cover;">
          </div>
          <div class="fakeimg"><p>Gundam Image 2</p>
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture4.png" alt="Image" style="width: 80%; height: 50%; object-fit: cover;">
          </div>
          <div class="fakeimg"><p>Gundam Image 3</p>
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture5.png" alt="Image" style="width: 80%; height: 50%; object-fit: cover;">
          </div>
        </div>
        <div class="card">
          <h3>Follow Me</h3>
          <p><a href="https://www.facebook.com" target="_blank">https://www.facebook.com</a></p>
        </div>
      </div>
    `;
    document.body.appendChild(main);
  }
  
  function footer() {
    const footer = document.createElement('div');
    footer.className = 'footer';
    footer.innerHTML = `
      <h2>Copyright @2024-2024 DLSU Student, All Rights Reserved.</h2>
    `;
    document.body.appendChild(footer);
  }
  
  function showContent(item) {
    const mainContent = document.getElementById('mainContent');
    mainContent.innerHTML = '';
  
    if (item === 'default') {
      mainContent.innerHTML = `
        <div class="card" id="defaultContent">
          <h2>Sample Gundam Website HTML</h2>
          <h5>Made on June 6, 2024</h5>
          <div class="fakeimg" style="overflow: hidden;">
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture2.png" alt="Image" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <h2>Gundam</h2>
          <p>Gundam is a Japanese military science fiction media franchise. Created by Yoshiyuki Tomino and Sunrise, the franchise features giant robots, or mecha, with the name "Gundam".</p>
        </div>`;
    } else if (item === 'item2') {
      mainContent.innerHTML = `
        <div class="card">
          <h2>Sample Honkai Star Website HTML</h2>
          <h5>Made on June 6, 2024</h5>
          <div class="fakeimg" style="overflow: hidden;">
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture6.png" alt="Image" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <h2>Honkai Star Rail</h2>
          <p>Honkai: Star Rail is a role-playing gacha video game developed by miHoYo, published by miHoYo in mainland China and worldwide by COGNOSPHERE, d/b/a HoYoverse.</p>
        </div>`;
    } else if (item === 'item3') {
      mainContent.innerHTML = `
        <div class="card" style="height: 400px; overflow-y: scroll;">
          <h2>Rick Astley, Never Gonna Give You Up</h2>
          <h5>Made on June 6, 2024</h5>
          <div class="fakeimg" style="overflow: hidden;">
            <img src="C:\\Users\\Jared\\Desktop\\CPG3\\module4\\picture7.png" alt="Image" style="width: 100%; height: 100%; object-fit: cover;">
          </div>
          <h2>Scrollable Topic</h2>
          <p>
            <div>[Intro]<br>
            Desert you<br>
            Ooh-ooh-ooh-ooh<br>
            Hurt you</div>
  
            <div><br>
            [Verse 1]<br>
            We're no strangers to love<br>
            You know the rules and so do I (Do I)<br>
            A full commitment's what I'm thinking of<br>
            You wouldn't get this from any other guy</div>
  
            <div><br>
            [Pre-Chorus]<br>
            I just wanna tell you how I'm feeling<br>
            Gotta make you understand</div>
  
            <div><br>
            [Chorus]<br>
            Never gonna give you up<br>
            Never gonna let you down<br>
            Never gonna run around and desert you<br>
            Never gonna make you cry<br>
            Never gonna say goodbye<br>
            Never gonna tell a lie and hurt you</div>
  
            <div><br>
            [Verse 2]<br>
            We've known each other for so long<br>
            Your heart's been aching, but you're too shy to say it (To say it)<br>
            Inside, we both know what's been going on (Going on)<br>
            We know the game, and we're gonna play it</div>
  
            <div><br>
            [Pre-Chorus]<br>
            And if you ask me how I'm feeling<br>
            Don't tell me you're too blind to see</div>
  
            <div><br>
            [Chorus]<br>
            Never gonna give you up<br>
            Never gonna let you down<br>
            Never gonna run around and desert you<br>
            Never gonna make you cry<br>
            Never gonna say goodbye<br>
            Never gonna tell a lie and hurt you<br>
            Never gonna give you up<br>
            Never gonna let you down<br>
            Never gonna run around and desert you<br>
            Never gonna make you cry<br>
            Never gonna say goodbye<br>
            Never gonna tell a lie and hurt you</div>
  
            <div><br>
            [Post-Chorus]<br>
            Ooh (Give you up)<br>
            Ooh-ooh (Give you up)<br>
            Ooh-ooh<br>
            Never gonna give, never gonna give (Give you up)<br>
            Ooh-ooh<br>
            Never gonna give, never gonna give (Give you up)</div>
  
            <div><br>
            [Bridge]<br>
            We've known each other for so long<br>
            Your heart's been aching, but you're too shy to say it (To say it)<br>
            Inside, we both know what's been going on (Going on)<br>
            We know the game, and we're gonna play it</div>
  
            <div><br>
            [Pre-Chorus]<br>
            I just wanna tell you how I'm feeling<br>
            Gotta make you understand</div>
  
            <div><br>
            [Chorus]<br>
            Never gonna give you up<br>
            Never gonna let you down<br>
            Never gonna run around and desert you<br>
            Never gonna make you cry<br>
            Never gonna say goodbye<br>
            Never gonna tell a lie and hurt you<br>
            Never gonna give you up<br>
            Never gonna let you down<br>
            Never gonna run around and desert you<br>
            Never gonna make you cry<br>
            Never gonna say goodbye<br>
            Never gonna tell a lie and hurt you</div>
  
            <div><br>
            [Outro]<br>
            Ooh-ooh<br>
            Never gonna give, never gonna give<br>
            Give you up<br>
            Ooh-ooh<br>
            Never gonna give, never gonna give<br>
            Give you up</div>
          </p>
        </div>`;
    }
  }
  
  function cal() {
    const existingCalc = document.getElementById('calculator');
    if (existingCalc) return;
  
    const calc = document.createElement('div');
    calc.id = 'calculator';
    calc.style.position = 'fixed';
    calc.style.top = '50px';
    calc.style.right = '50px';
    calc.style.width = '200px';
    calc.style.backgroundColor = 'white';
    calc.style.border = '1px solid black';
    calc.style.padding = '10px';
    calc.innerHTML = `
      <div style="margin-bottom: 10px;">
        <label for="calcDisplay">Calculator</label>
        <input type="text" id="calcDisplay" readonly style="width: 100%; margin-bottom: 10px;">
      </div>
      <div id="calcButtons">
        <button onclick="insert(1)">1</button>
        <button onclick="insert(2)">2</button>
        <button onclick="insert(3)">3</button>
        <button onclick="insert('+')">+</button>
        <button onclick="insert(4)">4</button>
        <button onclick="insert(5)">5</button>
        <button onclick="insert(6)">6</button>
        <button onclick="insert('-')">-</button>
        <button onclick="insert(7)">7</button>
        <button onclick="insert(8)">8</button>
        <button onclick="insert(9)">9</button>
        <button onclick="insert('*')">*</button>
        <button onclick="insert(0)">0</button>
        <button onclick="clearDisplay()">C</button>
        <button onclick="calculate()">=</button>
        <button onclick="insert('/')">/</button>
        <button onclick="closeCalculator()">Close</button>
      </div>
    `;
    document.body.appendChild(calc);
    makeDraggable(calc);
  }
  
  function insert(num) {
    document.getElementById('calcDisplay').value += num;
  }
  
  function clearDisplay() {
    document.getElementById('calcDisplay').value = '';
  }
  
  function calculate() {
    const display = document.getElementById('calcDisplay');
    try {
      display.value = eval(display.value);
    } catch {
      display.value = 'Error';
    }
  }
  
  function closeCalculator() {
    const calc = document.getElementById('calculator');
    if (calc) {
      document.body.removeChild(calc);
    }
  }
  
  function makeDraggable(element) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    element.onmousedown = dragMouseDown;
  
    function dragMouseDown(e) {
      e = e || window.event;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }
  
    function elementDrag(e) {
      e = e || window.event;
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      element.style.top = (element.offsetTop - pos2) + "px";
      element.style.left = (element.offsetLeft - pos1) + "px";
    }
  
    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }
  
  function sort() {
    const existingSorter = document.getElementById('textSorter');
    if (existingSorter) return;
  
    const sorter = document.createElement('div');
    sorter.id = 'textSorter';
    sorter.style.position = 'fixed';
    sorter.style.top = '100px';
    sorter.style.right = '50px';
    sorter.style.width = '300px';
    sorter.style.backgroundColor = 'white';
    sorter.style.border = '1px solid black';
    sorter.style.padding = '10px';
    sorter.innerHTML = `
      <div style="margin-bottom: 10px;">
        <label for="sortInput">Enter text to sort</label>
        <textarea id="sortInput" style="width: 100%; height: 100px; margin-bottom: 10px;"></textarea>
      </div>
      <div>
        <button onclick="sortText()">Sort</button>
        <button onclick="closeSorter()">Close</button>
      </div>
      <div style="margin-top: 10px;">
        <label for="sortOutput">Sorted text</label>
        <textarea id="sortOutput" style="width: 100%; height: 100px;" readonly></textarea>
      </div>
    `;
    document.body.appendChild(sorter);
    makeDraggable(sorter);
  }
  
  function sortText() {
    const input = document.getElementById('sortInput').value;
    const sorted = input.split('\n').sort().join('\n');
    document.getElementById('sortOutput').value = sorted;
  }
  
  function closeSorter() {
    const sorter = document.getElementById('textSorter');
    if (sorter) {
      document.body.removeChild(sorter);
    }
  }
  