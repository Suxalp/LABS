function oper(op) {
    const op1 = document.getElementById('op1').value;
    const op2 = document.getElementById('op2').value;
    const output = document.getElementById('output');

    if (op1 === '' || op2 === '') {
        alert('Inputs should not be empty.');
        return;
    }

    if (isNaN(op1) || isNaN(op2)) {
        alert('Please enter valid inputs.');
        return;
    }

    let result;
    
    switch (op) {
        case '+':
            result = parseFloat(op1) + parseFloat(op2);
            break;
        case '-':
            result = op1 - op2;
            break;
        case '*':
            result = op1 * op2;
            break;
        case '/':
            if (op2 === 0) {
                alert('Division by zero is not allowed.');
                return;
            }
            result = op1 / op2;
            break;
        default:
            alert('Invalid operator.');
            return;
    }

    output.value = result;
}
